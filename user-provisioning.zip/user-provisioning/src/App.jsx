import { useState } from 'react'

// TODO: replace with your actual roles
const ROLES = ['Role 1', 'Role 2', 'Role 3']

const initialForm = { firstName: '', lastName: '', email: '', role: '' }

export default function App() {
  const [form, setForm] = useState(initialForm)
  const [validated, setValidated] = useState(false)

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setValidated(true)
    if (!e.currentTarget.checkValidity()) return

    console.log('User provisioning data:', form)
  }

  return (
    <div className="container py-5" style={{ maxWidth: 600 }}>
      <h1 className="h3 mb-4">User Provisioning</h1>

      <form noValidate className={validated ? 'was-validated' : ''} onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="firstName" className="form-label">First Name</label>
          <input
            id="firstName"
            name="firstName"
            type="text"
            className="form-control"
            value={form.firstName}
            onChange={handleChange}
            required
          />
          <div className="invalid-feedback">First name is required.</div>
        </div>

        <div className="mb-3">
          <label htmlFor="lastName" className="form-label">Last Name</label>
          <input
            id="lastName"
            name="lastName"
            type="text"
            className="form-control"
            value={form.lastName}
            onChange={handleChange}
            required
          />
          <div className="invalid-feedback">Last name is required.</div>
        </div>

        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email Address</label>
          <input
            id="email"
            name="email"
            type="email"
            className="form-control"
            value={form.email}
            onChange={handleChange}
            required
          />
          <div className="invalid-feedback">A valid email address is required.</div>
        </div>

        <div className="mb-3">
          <label htmlFor="role" className="form-label">Role</label>
          <select
            id="role"
            name="role"
            className="form-select"
            value={form.role}
            onChange={handleChange}
            required
          >
            <option value="">Select a role...</option>
            {ROLES.map((r) => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
          <div className="invalid-feedback">Please select a role.</div>
        </div>

        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </div>
  )
}
