# User Provisioning (React + Vite + Bootstrap)

1. Install Node.js LTS (v20+): https://nodejs.org
2. In this folder run: `npm install`
3. Start the dev server: `npm run dev`
4. Open http://localhost:5173 and check the browser console (F12) after clicking Submit.

Edit the `ROLES` array at the top of `src/App.jsx` to set your role list.
